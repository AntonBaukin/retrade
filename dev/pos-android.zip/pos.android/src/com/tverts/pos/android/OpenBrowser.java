package com.tverts.pos.android;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class OpenBrowser extends Activity
{
	@Override
	public void onCreate(Bundle bundle)
	{
		super.onCreate(bundle);
		setContentView(view = new WebView(this));

		view.getSettings().setDefaultTextEncodingName("utf-8");
		view.getSettings().setJavaScriptEnabled(true);

		view.loadUrl(getString(R.string.url));
	}

	private WebView view;
}
